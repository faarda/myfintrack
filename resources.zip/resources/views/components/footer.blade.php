<footer>
    <div class="footer-main">
        <div class="footer-info">
            <ul>
                <li class="contact-info">
                    <div class="icon">
                        <span data-feather="map-pin"></span>
                    </div>
                    No. 5, Green-light Street, Abuja, Nigeria
                </li>
                <li class="contact-info">
                    <div class="icon">
                        <span data-feather="phone"></span>
                    </div>
                    (+234)011122233
                </li>
                <li class="contact-info">
                    <div class="icon">
                        <span data-feather="mail"></span>
                    </div>
                    frontdesk@poundsFT.com
                </li>
            </ul>
        </div>
    </div>
</footer>