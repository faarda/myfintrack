<div class="auth-option">OR</div>
<div class="social-auth">
  <a href="login/google" class='g-sign-in-button'>
    <div class=content-wrapper>
    <div class='logo-wrapper'>  
      <img src='/images/g-logo.png'>
      </div>  
      <span class='text-container'> 
        <span>Sign in with Google</span>
      </span>
    </div>  
  </a>
</div>